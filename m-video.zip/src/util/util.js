function isEmptyObject(e) {  
    let t;  
    for (t in e)  
        return !1;  
    return !0  
}
export default { isEmptyObject }