export default {
    // url : 'http://mz1639632292.tunnel.2bdata.com'
    url : '/api',
    newurl: '/api'
    // url: ''
}